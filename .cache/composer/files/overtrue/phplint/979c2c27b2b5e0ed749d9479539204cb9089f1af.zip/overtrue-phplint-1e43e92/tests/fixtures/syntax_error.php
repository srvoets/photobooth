<?php

print($a)
