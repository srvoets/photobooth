# Other CI Pipelines

Run this command using `overtrue/phplint:latest` Docker image:

```shell
/root/.composer/vendor/bin/phplint ./ --exclude=vendor
```
