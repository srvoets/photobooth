<?php

$options = [
    'label_format' => 'html',
    'show_private' => false,
    'show_protected' => false,
    'namespace_filter' => $namespaceFilter,
];
