<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'common.php';
