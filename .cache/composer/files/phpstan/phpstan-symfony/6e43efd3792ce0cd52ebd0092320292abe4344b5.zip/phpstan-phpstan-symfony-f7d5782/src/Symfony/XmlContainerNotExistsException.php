<?php declare(strict_types = 1);

namespace PHPStan\Symfony;

use InvalidArgumentException;

final class XmlContainerNotExistsException extends InvalidArgumentException
{

}
